/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author abeyz
 */
import javax.swing.JOptionPane ;
public class Carpma {
    


    public static void main (String[] args ) {
        int carpımtablosu; 
        int soruSay = Integer.parseInt(JOptionPane.showInputDialog(null, "Soru Sayısı..:" , "Çarpım Tablosu Ezberleme Oyunu" , 1));
        int tekrarSay = Integer.parseInt(JOptionPane.showInputDialog(null, "Soru Tekrar Sayısı..:" ,"Çarpım Tablosu Ezberleme Oyunu" , 1));
                soruAl(soruSay,tekrarSay);
     JOptionPane.showMessageDialog(null ,"\nOyun için teşekkürler. Bye...\n");
    }//main sonu
     public static void soruAl (int kez,int tekrarSay) {
        int num1 , num2 , cvp , ynt , tkr ;
        for (int h= 1 ; h<= kez ; h ++) {
            num1 = rasgele (1,10) ;
            num2 = rasgele (1,10) ;
            cvp =num1 * num2 ;
            for (tkr =1 ; tkr<=tekrarSay ; tkr ++) {
                JOptionPane.showMessageDialog(null,num1+"*"+num2, "Problem "+h+"["+tkr+"/"+tekrarSay+"]",1);
                ynt = Integer.parseInt(JOptionPane.showInputDialog(null,"Yanıtınız !")) ;
                if (ynt == cvp ) {
                    JOptionPane.showMessageDialog(null , "Bravo ! Bildiniz...: ");
                break ; }
                        if (tkr < tekrarSay)
                            JOptionPane.showMessageDialog(null, "Yanlış ,tekrar deneyiniz..: ",null, 2);
                        else
                            JOptionPane.showMessageDialog(null , cvp , "Maalesef doğrusu :" ,2) ;
                    } }
            } // soruAl sonu

    private static int rasgele(int m , int n) {
        return (int) (Math.random()  *  (n - m + 1)) + m ;
        } //rasgele fonksiyon sonu
        } //class sonu

    
 
